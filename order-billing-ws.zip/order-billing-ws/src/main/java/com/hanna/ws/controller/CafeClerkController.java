package com.hanna.ws.controller;

import com.hanna.ws.entity.CafeClerk;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/order-billing-ws")
public class CafeClerkController {

    @Autowired
    private final CafeClerk clerk;

    public CafeClerkController(CafeClerk clerk) {
        this.clerk = clerk;
    }

    @GetMapping("/getCafeClerk")
    public String getCafeClerk() {
        return clerk.getName();
    }
}