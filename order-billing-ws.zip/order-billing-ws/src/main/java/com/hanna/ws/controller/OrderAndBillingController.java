package com.hanna.ws.controller;

import com.hanna.ws.entity.CafeClerk;
import com.hanna.ws.entity.Order;
import com.hanna.ws.impl.DiscountedBill;
import com.hanna.ws.impl.OrderBill;
import com.hanna.ws.impl.RegularBill;
import com.hanna.ws.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/order-billing-ws")
public class OrderAndBillingController {

    @Autowired
    private OrderRepository orderRepository;
    private final CafeClerk clerk;

    public OrderAndBillingController(CafeClerk clerk) {
        this.clerk = clerk;
    }

    @GetMapping("/getOrders")
    public List<Order> getOrderList() {
        return orderRepository.findAll();
    }

    @PostMapping("/addOrder")
    public Order addOrder(@RequestBody Order order) {
        return orderRepository.save(order);
    }

    @PutMapping("/updateOrder/{id}")
    public Order updateOrder(@PathVariable Long id, @RequestBody Order order) {
        order.setId(id);
        return orderRepository.save(order);
    }

    @DeleteMapping("/deleteOrder/{id}")
    public void deleteOrder(@PathVariable Long id) {
        orderRepository.deleteById(id);
    }

    @GetMapping("/getTotalRegularBill")
    public OrderBill getTotalRegularBill() {
        OrderBill orderBill = new RegularBill(clerk);
        orderBill.setOrderList(getOrderList());
        return orderBill;
    }

    @GetMapping("/getTotalDiscountedBill")
    public OrderBill getTotalDiscountedBill() {
        OrderBill orderBill = new DiscountedBill(clerk);
        orderBill.setOrderList(getOrderList());
        return orderBill;
    }
}
