package com.hanna.ws.impl;

import com.hanna.ws.entity.CafeClerk;

public class DiscountedBill extends OrderBill {

    public DiscountedBill(CafeClerk clerk) {
        super(clerk);
    }

    @Override
    public double getTotalBill() {
        return getOrderList().stream()
                .mapToDouble(order -> {
                    if (order.isDiscounted()) {
                        return order.getPrice() * (1 - order.getDiscountedPercentage() / 100.0);
                    } else {
                        return order.getPrice();
                    }
                })
                .sum();
    }
}
