module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'custom-blue': '#052a75',
      },
      borderWidth: {
        'outset': '3px',
      },
      boxShadow: {
        'outset': '0 0 0 1px rgba(0, 0, 0, 1)',
      },
    },
  },
  plugins: [
    function ({ addUtilities }) {
      addUtilities({
        '.border-outset': {
          'border-style': 'outset',
        },
      }, ['responsive', 'hover'])
    }
  ],
}