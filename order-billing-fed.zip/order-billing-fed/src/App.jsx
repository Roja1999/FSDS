import React from 'react';
import { Provider } from 'react-redux';
import store from './redux/store';
import OrderProvider from './context/OrderContext';
import Header from './components/Header.jsx';
import DiscountMessage from './components/DiscountMessage.jsx';
import OrderForm from './components/OrderForm.jsx';
import OrderList from './components/OrderList.jsx';
import SideMenu from './components/SideMenu.jsx';
import Footer from './components/Footer.jsx';
import ToastContainer from './components/ToastContainer';
import withErrorBoundary from './hoc/withErrorBoundary';
import './styles/App.css';

const App = () => (
  <Provider store={store}>
    <OrderProvider>
      <div className="flex flex-col min-h-screen bg-gray-100">
        <Header />
        <DiscountMessage />
        <ToastContainer />
        <main className="flex-1 flex">
          <SideMenu />
          <div className="flex-1 p-4">
            <OrderForm />
            <OrderList />
          </div>
        </main>
        <Footer />
      </div>
    </OrderProvider>
  </Provider>
);

export default withErrorBoundary(App);