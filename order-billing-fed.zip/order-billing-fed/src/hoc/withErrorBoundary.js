import React from 'react';
import ErrorMessage from '../components/ErrorMessage';

const withErrorBoundary = (WrappedComponent) => {
    class ErrorBoundary extends React.Component {
        constructor(props) {
            super(props);
            this.state = { hasError: false, errorMessage: '' };
        }

        static getDerivedStateFromError(error) {
            return { hasError: true, errorMessage: error.message };
        }

        componentDidCatch(error, errorInfo) {
            console.error('Error caught in ErrorBoundary:', error, errorInfo);
        }

        render() {
            if (this.state.hasError) {
                return <ErrorMessage message={this.state.errorMessage} />;
            }

            return <WrappedComponent {...this.props} />;
        }
    }

    return ErrorBoundary;
};

export default withErrorBoundary;