import React from 'react';

const Header = () => (
    <header className="bg-gray-900 text-white p-4">
        <div className="container flex justify-between items-center">
            <img src="images/header-img.png" alt="Logo" className="h-20" />
        </div>
    </header>
);

export default Header;