import React, { useContext, useState } from 'react';
import { OrderContext } from '../context/OrderContext';

const OrderList = () => {
    const { orders, clerk, deleteOrder, updateOrder } = useContext(OrderContext);
    const [editingOrderId, setEditingOrderId] = useState(null);
    const [editForm, setEditForm] = useState({ orderName: '', price: '', promo: false });
    const [errors, setErrors] = useState({});

    const validate = () => {
        const newErrors = {};
        if (!editForm.orderName) newErrors.orderName = 'Order name is required';
        if (!editForm.price || editForm.price <= 0) newErrors.price = 'Price must be positive';
        return newErrors;
    };

    const handleEdit = (order) => {
        setEditingOrderId(order.id);
        setEditForm({ orderName: order.orderName, price: order.price, promo: order.isDiscounted });
    };

    const handleCancel = () => {
        setEditingOrderId(null);
        setEditForm({ orderName: '', price: '', promo: false });
        setErrors({});
    };

    const handleChange = (e) => {
        const { name, value, checked, type } = e.target;
        setEditForm((prevForm) => ({
            ...prevForm,
            [name]: type === 'checkbox' ? checked : value,
        }));
    };

    const handleSubmit = (order) => {
        const newErrors = validate();
        if (Object.keys(newErrors).length > 0) {
            setErrors(newErrors);
        } else {
            updateOrder({ ...order, ...editForm, isDiscounted: editForm.promo });
            handleCancel();
        }
    };

    const totalRegularBill = orders.reduce((total, order) => total + parseFloat(order.price), 0);
    const totalDiscountedBill = orders.reduce(
        (total, order) => total + (order.isDiscounted ? parseFloat(order.price) * 0.95 : parseFloat(order.price)),
        0
    );

    return (
        <div className="w-full bg-white p-1 rounded shadow-md border-outset mt-4">
            <table className="w-full table-auto">
                <thead>
                    <tr>
                        <td colSpan="4" className="px-4 py-2 text-center">
                            Attending Clerk: {clerk}
                        </td>
                    </tr>
                    <tr className="bg-custom-blue text-white">
                        <th className="p-4">Order Item</th>
                        <th className="p-4">Price</th>
                        <th className="p-4">Promo</th>
                        <th className="p-4">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {orders.map((order) =>
                        editingOrderId === order.id ? (
                            <tr key={order.id} className="border-b-2">
                                <td className="px-4 py-2">
                                    <input
                                        type="text"
                                        name="orderName"
                                        value={editForm.orderName}
                                        onChange={handleChange}
                                        className="w-full p-2 border border-gray-300 rounded"
                                    />
                                    {errors.orderName && <div className="text-red-500 text-sm">{errors.orderName}</div>}
                                </td>
                                <td className="px-4 py-2">
                                    <input
                                        type="number"
                                        name="price"
                                        value={editForm.price}
                                        onChange={handleChange}
                                        className="w-full p-2 border border-gray-300 rounded"
                                    />
                                    {errors.price && <div className="text-red-500 text-sm">{errors.price}</div>}
                                </td>
                                <td className="px-4 py-2">
                                    <input type="checkbox" name="promo" checked={editForm.promo} onChange={handleChange} />
                                </td>
                                <td className="px-4 py-2">
                                    <button onClick={() => handleSubmit(order)} className="underline text-blue-300 px-4 py-2">
                                        Change
                                    </button>
                                    <button onClick={handleCancel} className="underline text-blue-300 px-4 py-2">
                                        Cancel
                                    </button>
                                </td>
                            </tr>
                        ) : (
                            <tr key={order.id} className="border-b-2">
                                <td className="px-4 py-2 text-center">{order.orderName}</td>
                                <td className="px-4 py-2 text-center">{order.price}</td>
                                <td className="px-4 py-2 text-center">{order.isDiscounted ? 'Yes' : 'No'}</td>
                                <td className="px-4 py-2 text-center">
                                    <button onClick={() => handleEdit(order)} className="underline text-blue-300 px-4 py-2">
                                        Edit
                                    </button>
                                    <button onClick={() => deleteOrder(order.id)} className="underline text-blue-300 px-4 py-2">
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        )
                    )}
                    <tr>
                        <td colSpan="4" className="px-4 py-2 text-center">
                            Total regular bill: ${totalRegularBill.toFixed(2)}
                        </td>
                    </tr>
                    <tr>
                        <td colSpan="4" className="px-4 py-2 text-center">
                            Total discounted bill: ${totalDiscountedBill.toFixed(2)}
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    );
};

export default OrderList;