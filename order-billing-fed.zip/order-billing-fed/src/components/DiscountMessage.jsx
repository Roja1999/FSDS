import React from 'react';

const DiscountMessage = () => (
    <div className="overflow-hidden whitespace-nowrap bg-blue-800 text-white py-4">
        <div className="inline-block animate-marquee">
            <p className="text-xl text-center uppercase font-semibold px-4">
                5% discount on all espresso bar drinks!!! Buy now!
            </p>
        </div>
    </div>
);

export default DiscountMessage;