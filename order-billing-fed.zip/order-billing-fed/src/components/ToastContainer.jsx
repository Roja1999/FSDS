// src/components/ToastContainer.jsx
import React, { useEffect, useState, useContext } from 'react';
import { OrderContext } from '../context/OrderContext';

const ToastContainer = () => {
    const { toast, showToast } = useContext(OrderContext);
    const [show, setShow] = useState("");

    useEffect(() => {
        if (toast) {
            setShow(toast.type === "" ? "hidden" : "");
            const timer = setTimeout(() => {
                showToast({ message: '', type: '' });
            }, 3000); // Auto-hide after 3 seconds
            return () => clearTimeout(timer);
        }
    }, [toast, showToast]);

    return (toast && <div className={`bg-${toast.type}-500 text-white p-4 w-full ${show}`}>
        <div className="flex items-center justify-between">
            <span>{toast.message}</span>
            <button onClick={() => showToast({ message: '', type: '' })} className="ml-4 focus:outline-none">
                &#x2715;
            </button>
        </div>
    </div>
    );
};

export default ToastContainer;