import React, { createContext, useReducer, useEffect, useCallback } from 'react';
import orderReducer, {
    setClerk,
    setOrders,
    addOrder,
    deleteOrder,
    updateOrder,
    setEditMode,
    clearEditMode,
    setError,
    showToast,
} from '../redux/reducers';

export const OrderContext = createContext();

const OrderProvider = ({ children }) => {
    const [state, dispatch] = useReducer(orderReducer, {
        orders: [],
        toast: {
            message: '',
            type: ''
        },
        error: null,
        editMode: null,
    });

    // Memoize fetchOrders using useCallback
    const fetchOrders = useCallback(async () => {
        try {
            const response = await fetch('http://localhost:9090/order-billing-ws/getOrders');
            const orders = await response.json();
            dispatch(setOrders(orders));
            dispatch(showToast({ message: 'Orders fetched successfully', type: 'green' }));
        } catch (error) {
            dispatch(setError('Unable to fetch orders'));
            dispatch(showToast({ message: 'Failed to fetch orders', type: 'red' }));
        }
    }, [dispatch]);

    const fetchClerk = useCallback(async () => {
        try {
            const response = await fetch('http://localhost:9090/order-billing-ws/getCafeClerk');
            const clerk = await response.text();
            dispatch(setClerk(clerk));
        } catch (error) {
            dispatch(setError('Unable to fetch clerk'));
        }
    }, [dispatch]);

    useEffect(() => {
        (async () => {
            await fetchOrders();
            await fetchClerk();
        })();
    }, [fetchOrders, fetchClerk]);

    const addOrderToState = async (order) => {
        try {
            const response = await fetch('http://localhost:9090/order-billing-ws/addOrder', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    orderName: order.orderName,
                    price: parseFloat(order.price),
                    isDiscounted: order.promo
                }),
            });
            const newOrder = await response.json();
            dispatch(addOrder(newOrder));
            dispatch(showToast({ message: 'Order added successfully', type: 'green' }));
        } catch (error) {
            dispatch(setError('Unable to add order'));
            dispatch(showToast({ message: 'Failed to add order', type: 'red' }));
        }
    };

    const deleteOrderFromState = async (orderId) => {
        try {
            await fetch(`http://localhost:9090/order-billing-ws/deleteOrder/${orderId}`, {
                method: 'DELETE',
            });
            dispatch(deleteOrder(orderId));
            dispatch(showToast({ message: 'Order deleted successfully', type: 'green' }));
        } catch (error) {
            dispatch(setError('Unable to delete order'));
            dispatch(showToast({ message: 'Failed to delete order', type: 'red' }));
        }
    };

    const updateOrderInState = async (order) => {
        try {
            const response = await fetch(`http://localhost:9090/order-billing-ws/updateOrder/${order.id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(order),
            });
            const updatedOrder = await response.json();
            dispatch(updateOrder(updatedOrder));
            dispatch(showToast({ message: 'Order updated successfully', type: 'green' }));
        } catch (error) {
            dispatch(setError('Unable to update order'));
            dispatch(showToast({ message: 'Failed to update order', type: 'red' }));
        }
    };

    const showToastToState = (toast) => {
        dispatch(showToast(toast));
    };

    return (
        <OrderContext.Provider
            value={{
                orders: state.orders,
                clerk: state.clerk,
                toast: state.toast,
                showToast: showToastToState,
                addOrder: addOrderToState,
                deleteOrder: deleteOrderFromState,
                updateOrder: updateOrderInState,
                setEditMode: (order) => dispatch(setEditMode(order)),
                clearEditMode: () => dispatch(clearEditMode()),
                editMode: state.editMode,
            }}
        >
            {children}
        </OrderContext.Provider>
    );
};

export default OrderProvider;